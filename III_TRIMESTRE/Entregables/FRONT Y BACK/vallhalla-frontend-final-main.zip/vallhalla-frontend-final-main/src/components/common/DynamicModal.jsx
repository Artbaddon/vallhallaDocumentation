import React, { useEffect, memo } from 'react';
import PropTypes from 'prop-types';
import './DynamicModal.css';

/**
 * A reusable modal component that can be used throughout the application
 * 
 * @param {boolean} show - For compatibility with Bootstrap Modal
 * @param {boolean} isOpen - For compatibility with React Modal
 * @param {function} onHide - For compatibility with Bootstrap Modal
 * @param {function} onClose - For compatibility with React Modal
 * @param {string} title - The title of the modal
 * @param {React.ReactNode} children - The content of the modal
 * @param {function} onSubmit - Function to call when the form is submitted
 * @param {string} submitText - Text to display on the submit button
 * @param {string} size - Size of the modal (sm, md, lg, xl)
 * @param {boolean} showFooter - Whether to show the footer with buttons
 * @returns {React.ReactElement|null} The modal component or null if not open
 */
const DynamicModalComponent = ({ 
  show, // For compatibility with Bootstrap Modal
  isOpen, // For compatibility with React Modal
  onHide, // For compatibility with Bootstrap Modal
  onClose, // For compatibility with React Modal
  title, 
  children,
  onSubmit,
  submitText = 'Guardar',
  size = 'md', // sm, md, lg, xl
  showFooter = true
}) => {
  // Support both show and isOpen props
  const isModalOpen = show || isOpen;
  // Support both onHide and onClose props
  const handleClose = onHide || onClose;

  if (!isModalOpen) return null;

  // Prevent background scroll when modal is open
  useEffect(() => {
    document.body.classList.add('modal-open');
    return () => {
      document.body.classList.remove('modal-open');
    };
  }, [isModalOpen]);

  // Close modal on escape key
  useEffect(() => {
    const handleEscapeKey = (e) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };
    document.addEventListener('keydown', handleEscapeKey);
    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [handleClose]);

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  return (
    <div className="modal-overlay" onClick={handleBackdropClick}>
      <div className={`modal fade show`} style={{ display: 'block' }} tabIndex="-1">
        <div className={`modal-dialog modal-${size}`}>
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button type="button" className="btn-close" onClick={handleClose} aria-label="Close"></button>
            </div>
            {onSubmit ? (
              <form onSubmit={onSubmit}>
                <div className="modal-body">{children}</div>
                {showFooter && (
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={handleClose}>
                      Cancelar
                    </button>
                    <button type="submit" className="btn btn-primary">
                      {submitText}
                    </button>
                  </div>
                )}
              </form>
            ) : (
              <>
                <div className="modal-body">{children}</div>
                {showFooter && (
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={handleClose}>
                      Cerrar
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show"></div>
    </div>
  );
};

DynamicModalComponent.propTypes = {
  show: PropTypes.bool,
  isOpen: PropTypes.bool,
  onHide: PropTypes.func,
  onClose: PropTypes.func,
  title: PropTypes.string.isRequired,
  children: PropTypes.node,
  onSubmit: PropTypes.func,
  submitText: PropTypes.string,
  size: PropTypes.oneOf(['sm', 'md', 'lg', 'xl']),
  showFooter: PropTypes.bool
};

DynamicModalComponent.displayName = 'DynamicModalComponent';

// Create a memoized version with proper displayName
const DynamicModal = memo(DynamicModalComponent);
DynamicModal.displayName = 'DynamicModal';

export default DynamicModal; 