// This file serves as a compatibility layer for existing imports
// It re-exports everything from apiService.js

// Re-export everything from apiService.js for backward compatibility
import api, {
  apartmentsAPI,
  towersAPI,
  apartmentStatusAPI,
  ownersAPI,
  authAPI,
  usersAPI,
  rolesAPI,
  vehicleTypesAPI,
  pqrsAPI,
  pqrsCategoriesAPI,
  visitorsAPI,
  facilitiesAPI,
  permissionsAPI,
  parkingAPI,
  petsAPI,
  paymentsAPI,
  reservationsAPI
} from './apiService';

import axios from 'axios';

// Create API client instance
const apiClient = axios.create({
  baseURL: 'http://localhost:3000/api', // adjust this to match your backend URL
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests if available
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export {
  apartmentsAPI,
  towersAPI,
  apartmentStatusAPI,
  ownersAPI,
  authAPI,
  usersAPI,
  rolesAPI,
  vehicleTypesAPI,
  pqrsAPI,
  pqrsCategoriesAPI,
  visitorsAPI,
  facilitiesAPI,
  permissionsAPI,
  parkingAPI,
  petsAPI,
  paymentsAPI,
  reservationsAPI
};

export const tenantsAPI = {
  getDetails: async () => {
    const response = await apiClient.get('/tenant/details');
    return response.data;
  },

  create: async (data) => {
    const response = await apiClient.post('/tenant', data);
    return response.data;
  },

  update: async (id, data) => {
    const response = await apiClient.put(`/tenant/${id}`, data);
    return response.data;
  },

  delete: async (id) => {
    const response = await apiClient.delete(`/tenant/${id}`);
    return response.data;
  }
};

export default api; 