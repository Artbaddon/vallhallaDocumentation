import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useQuery } from 'react-query';
import { ownersAPI } from '../../../services/api';
import Modal from 'react-modal';

// Make sure to bind modal to your app element
Modal.setAppElement('#root');

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    maxWidth: '500px',
    width: '90%',
    padding: '20px',
    borderRadius: '8px',
  },
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 1000,
  },
};

const VisitorModal = ({ isOpen, onClose, onSubmit, visitor }) => {
  const isEditing = !!visitor;
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm({
    defaultValues: {
      visitor_name: visitor?.visitor_name || '',
      document_number: visitor?.document_number || '',
      host_id: visitor?.host_id || '',
    },
  });

  // Fetch owners for dropdown
  const { data: ownersResponse, isLoading: loadingOwners } = useQuery('owners', ownersAPI.getAll, {
    onSuccess: (response) => {
      console.log('Owners data received:', response?.data);
    },
    onError: (err) => {
      console.error('Error fetching owners:', err);
    }
  });

  // Ensure owners is always an array
  const owners = Array.isArray(ownersResponse?.data) ? ownersResponse.data : [];

  useEffect(() => {
    if (isOpen) {
      reset({
        visitor_name: visitor?.visitor_name || '',
        document_number: visitor?.document_number || '',
        host_id: visitor?.host_id || '',
      });
    }
  }, [isOpen, visitor, reset]);

  const submitForm = (data) => {
    onSubmit(data);
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onClose}
      style={customStyles}
      contentLabel="Visitor Modal"
    >
      <div className="modal-header">
        <h2>{isEditing ? 'Editar Visitante' : 'Registrar Nuevo Visitante'}</h2>
        <button type="button" className="btn-close" onClick={onClose}></button>
      </div>
      
      <form onSubmit={handleSubmit(submitForm)}>
        <div className="modal-body">
          <div className="mb-3">
            <label htmlFor="visitor_name" className="form-label">Nombre del Visitante</label>
            <input
              type="text"
              className={`form-control ${errors.visitor_name ? 'is-invalid' : ''}`}
              id="visitor_name"
              {...register('visitor_name', { required: 'Este campo es requerido' })}
            />
            {errors.visitor_name && (
              <div className="invalid-feedback">
                {errors.visitor_name.message}
              </div>
            )}
          </div>
          
          <div className="mb-3">
            <label htmlFor="document_number" className="form-label">Número de Documento</label>
            <input
              type="text"
              className={`form-control ${errors.document_number ? 'is-invalid' : ''}`}
              id="document_number"
              {...register('document_number', { required: 'Este campo es requerido' })}
            />
            {errors.document_number && (
              <div className="invalid-feedback">
                {errors.document_number.message}
              </div>
            )}
          </div>
          
          <div className="mb-3">
            <label htmlFor="host_id" className="form-label">Anfitrión</label>
            <select
              className={`form-select ${errors.host_id ? 'is-invalid' : ''}`}
              id="host_id"
              {...register('host_id', { required: 'Debe seleccionar un anfitrión' })}
            >
              <option value="">Seleccionar anfitrión</option>
              {loadingOwners ? (
                <option value="" disabled>Cargando anfitriones...</option>
              ) : (
                owners.map((owner) => (
                  <option key={owner.Owner_id} value={owner.Owner_id}>
                    {owner.Owner_first_name || owner.Owner_name || ''} {owner.Owner_last_name || ''} - {owner.Owner_document_number || ''}
                  </option>
                ))
              )}
            </select>
            {errors.host_id && (
              <div className="invalid-feedback">
                {errors.host_id.message}
              </div>
            )}
          </div>
        </div>
        
        <div className="modal-footer">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancelar
          </button>
          <button type="submit" className="btn btn-primary">
            {isEditing ? 'Actualizar' : 'Registrar'}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default VisitorModal; 