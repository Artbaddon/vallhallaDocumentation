import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { pqrsAPI, pqrsCategoriesAPI } from "../../../services/api";
import toast from "react-hot-toast";
import Swal from "sweetalert2";
import PQRSModal from "./PQRSModal";
import "./PQRS.css";

const PQRS = () => {
  const [showModal, setShowModal] = useState(false);
  const [currentPQRS, setCurrentPQRS] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const queryClient = useQueryClient();

  // Fetch PQRS data
  const { data: pqrsList = [], isLoading } = useQuery("pqrs", pqrsAPI.getAll, {
    select: (res) => res.pqrs,
  });

  // Fetch PQRS categories for filtering
  const { data: categories = [] } = useQuery(
    "pqrsCategories",
    pqrsCategoriesAPI.getAll,
    {
      select: (res) => res.categories,
    }
  );

  // Delete mutation
  const deleteMutation = useMutation(pqrsAPI.delete, {
    onSuccess: () => {
      queryClient.invalidateQueries("pqrs");
      toast.success("PQRS eliminado exitosamente");
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || "Error al eliminar PQRS");
    },
  });

  // Update status mutation
  const updateStatusMutation = useMutation(
    ({ id, data }) => pqrsAPI.updateStatus(id, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("pqrs");
        toast.success("Estado actualizado exitosamente");
      },
      onError: (error) => {
        toast.error(
          error.response?.data?.message || "Error al actualizar estado"
        );
      },
    }
  );

  const handleOpenModal = (pqrs = null) => {
    setCurrentPQRS(pqrs);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setCurrentPQRS(null);
  };

  const handleDelete = (id) => {
    Swal.fire({
      title: "¿Está seguro?",
      text: "Esta acción no se puede deshacer",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc3545",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteMutation.mutate(id);
      }
    });
  };

  const handleUpdateStatus = (id, statusId) => {
    Swal.fire({
      title: "Actualizar Estado",
      input: "textarea",
      inputLabel: "Respuesta (opcional)",
      inputPlaceholder: "Ingrese una respuesta o comentario...",
      showCancelButton: true,
      confirmButtonText: "Actualizar",
      cancelButtonText: "Cancelar",
      showLoaderOnConfirm: true,
      preConfirm: (adminResponse) => {
        return updateStatusMutation.mutateAsync({
          id,
          data: {
            status_id: statusId,
            admin_response: adminResponse || "",
          },
        });
      },
    });
  };

  // Filter PQRS by status and category
  const filteredPQRS = pqrsList.filter((pqrs) => {
    const categoryId = pqrs.PQRS_category_FK_ID ?? "";

    const categoryMatch =
      categoryFilter === "all" || categoryId.toString() === categoryFilter;

    return categoryMatch;
  });

  // Get status name
  const getStatusName = (statusId) => {
    const statuses = {
      1: "Pendiente",
      2: "En proceso",
      3: "Resuelto",
      4: "Cerrado",
    };
    return statuses[statusId] || "Desconocido";
  };

  // Get status badge class
  const getStatusBadgeClass = (statusId) => {
    const classes = {
      1: "badge bg-warning",
      2: "badge bg-primary",
      3: "badge bg-success",
      4: "badge bg-secondary",
    };
    return classes[statusId] || "badge bg-light";
  };

  // Get category name
  const getCategoryName = (categoryId) => {
    const category = categories.find((cat) => cat.id === categoryId);
    return category ? category.name : "Desconocido";
  };

  return (
    <div className="container-fluid mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestión de PQRS</h2>
        <button className="btn btn-primary" onClick={() => handleOpenModal()}>
          Crear PQRS
        </button>
      </div>

      <div className="card">
        <div className="card-header">
          <div className="row">
            <div className="col-md-6">
              <div className="input-group">
                <span className="input-group-text">Estado</span>
                <select
                  className="form-select"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">Todos</option>
                  <option value="1">Pendiente</option>
                  <option value="2">En proceso</option>
                  <option value="3">Resuelto</option>
                  <option value="4">Cerrado</option>
                </select>
              </div>
            </div>
            <div className="col-md-6">
              <div className="input-group">
                <span className="input-group-text">Categoría</span>
                <select
                  className="form-select"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="all">Todas</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id.toString()}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          {isLoading ? (
            <div className="text-center">
              <div className="spinner-border" role="status">
                <span className="visually-hidden">Cargando...</span>
              </div>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Asunto</th>
                    <th>Categoría</th>
                    <th>Propietario</th>
                    <th>Estado</th>
                    <th>Prioridad</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPQRS.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="text-center">
                        No hay PQRS registrados
                      </td>
                    </tr>
                  ) : (
                    filteredPQRS.map((pqrs) => (
                      <tr key={pqrs.PQRS_id}>
                        <td>{pqrs.PQRS_id}</td>
                        <td>{pqrs.PQRS_subject}</td>
                        <td>
                          {pqrs.PQRS_category_name ||
                            getCategoryName(pqrs.PQRS_category_FK_ID)}
                        </td>
                        <td>{pqrs.owner_name || `ID: ${pqrs.Owner_id}`}</td>
                        <td>
                          {/* Aquí como no tienes status_id, puedes mostrar algo fijo o vacío */}
                          <span className="badge bg-secondary">Sin estado</span>
                        </td>
                        <td>
                          <span
                            className={`badge ${
                              pqrs.PQRS_priority === "HIGH"
                                ? "bg-danger"
                                : pqrs.PQRS_priority === "MEDIUM"
                                ? "bg-warning"
                                : "bg-info"
                            }`}
                          >
                            {pqrs.PQRS_priority}
                          </span>
                        </td>
                        <td>
                          {new Date(pqrs.PQRS_createdAt).toLocaleDateString()}
                        </td>
                        <td>
                          <div className="btn-group">
                            <button
                              className="btn btn-sm btn-outline-primary"
                              onClick={() => handleOpenModal(pqrs)}
                              title="Ver detalles"
                            >
                              <i className="bi bi-eye"></i>
                            </button>
                            <button
                              className="btn btn-sm btn-outline-success"
                              onClick={() =>
                                /* Si tienes status_id, puedes manejar actualización; si no, deshabilita o elimina */
                                alert("Función actualizar estado no disponible")
                              }
                              title="Actualizar estado"
                              disabled
                            >
                              <i className="bi bi-arrow-clockwise"></i>
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              onClick={() => handleDelete(pqrs.PQRS_id)}
                              title="Eliminar"
                            >
                              <i className="bi bi-trash"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <PQRSModal
        show={showModal}
        handleClose={handleCloseModal}
        pqrs={currentPQRS}
        categories={categories}
      />
    </div>
  );
};

export default PQRS;
