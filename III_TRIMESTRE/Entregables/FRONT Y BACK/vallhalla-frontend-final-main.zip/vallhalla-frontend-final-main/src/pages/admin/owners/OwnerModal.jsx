import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import DynamicModal from '../../../components/common/DynamicModal';
import './OwnerModal.css';

const OwnerModal = ({ show, onHide, onSubmit, owner, isLoading, viewOnly }) => {
  const [isTenant, setIsTenant] = useState(false);
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
    setValue,
    watch
  } = useForm();

  useEffect(() => {
    if (show && owner) {
      // Populate form for editing or viewing
      setValue('username', owner.username || '');
      setValue('password', ''); // Don't populate password for security
      setValue('user_status_id', owner.userStatusId || 1);
      setValue('role_id', 3); // Default role for owners
      setValue('is_tenant', owner.isTenant || false);
      setIsTenant(owner.isTenant || false);
      setValue('birth_date', owner.birthDate ? owner.birthDate.split('T')[0] : '');
      setValue('first_name', owner.fullName?.split(' ')[0] || '');
      setValue('last_name', owner.fullName?.split(' ').slice(1).join(' ') || '');
      setValue('document_type', owner.documentType || 'CC');
      setValue('document_number', owner.documentNumber || '');
      setValue('phone', owner.phone || '');
      setValue('email', owner.email || '');
    } else if (show) {
      // Reset form for creating
      reset({
        username: '',
        password: '',
        user_status_id: 1,
        role_id: 3,
        is_tenant: false,
        birth_date: '',
        first_name: '',
        last_name: '',
        document_type: 'CC',
        document_number: '',
        phone: '',
        email: '',
        photo_url: null
      });
      setIsTenant(false);
    }
  }, [show, owner, setValue, reset]);

  const onSubmitForm = (data) => {
    const formattedData = {
      username: data.username,
      password: data.password,
      user_status_id: parseInt(data.user_status_id),
      role_id: 3, // Fixed role for owners
      is_tenant: data.is_tenant,
      birth_date: data.birth_date,
      first_name: data.first_name,
      last_name: data.last_name,
      document_type: data.document_type,
      document_number: data.document_number,
      phone: data.phone,
      email: data.email,
      photo_url: null
    };
    
    onSubmit(formattedData);
  };

  const userStatusLabels = {
    1: 'Activo',
    2: 'Inactivo',
    3: 'Pendiente'
  };

  return (
    <DynamicModal
      show={show}
      onHide={onHide}
      title={viewOnly ? "Detalles del Propietario" : owner ? "Editar Propietario" : "Nuevo Propietario"}
      size="lg"
      showFooter={!viewOnly}
      submitText={owner ? "Guardar Cambios" : "Crear Propietario"}
      onSubmit={!viewOnly ? handleSubmit(onSubmitForm) : undefined}
      isLoading={isLoading}
    >
      <form className="needs-validation">
        <div className="modal-body">
          <div className="mb-4">
            <h6 className="form-section-title">Información de Cuenta</h6>
            <div className="row g-3">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="username">
                    Nombre de Usuario {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="text"
                    className={`form-control ${errors.username ? 'is-invalid' : ''}`}
                    id="username"
                    placeholder="Ingrese nombre de usuario"
                    {...register('username', { 
                      required: !viewOnly ? 'El nombre de usuario es requerido' : false,
                      minLength: { value: 3, message: 'Mínimo 3 caracteres' }
                    })}
                    readOnly={viewOnly}
                  />
                  {errors.username && <div className="invalid-feedback">{errors.username.message}</div>}
                </div>
              </div>

              {!viewOnly && (
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="password">
                      Contraseña {!owner && <span className="text-danger">*</span>}
                    </label>
                    <input
                      type="password"
                      className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                      id="password"
                      placeholder="Ingrese contraseña"
                      {...register('password', {
                        required: !owner ? 'La contraseña es requerida' : false,
                        minLength: { value: 8, message: 'Mínimo 8 caracteres' }
                      })}
                    />
                    {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
                    {owner && <small className="text-muted">Dejar en blanco para mantener la actual</small>}
                  </div>
                </div>
              )}

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="user_status_id">Estado</label>
                  {viewOnly ? (
                    <input
                      type="text"
                      className="form-control"
                      value={userStatusLabels[watch('user_status_id')] || 'Desconocido'}
                      readOnly
                    />
                  ) : (
                    <select 
                      className="form-select" 
                      id="user_status_id"
                      {...register('user_status_id')}
                    >
                      <option value="1">Activo</option>
                      <option value="2">Inactivo</option>
                      <option value="3">Pendiente</option>
                    </select>
                  )}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="is_tenant" className="d-block">¿Es inquilino?</label>
                  {viewOnly ? (
                    <input
                      type="text"
                      className="form-control"
                      value={isTenant ? 'Sí' : 'No'}
                      readOnly
                    />
                  ) : (
                    <div className="form-check">
                      <input
                        type="checkbox"
                        className="form-check-input"
                        id="is_tenant"
                        {...register('is_tenant')}
                        onChange={(e) => setIsTenant(e.target.checked)}
                        checked={isTenant}
                      />
                      <label className="form-check-label" htmlFor="is_tenant">
                        {isTenant ? 'Sí' : 'No'}
                      </label>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h6 className="form-section-title">Información Personal</h6>
            <div className="row g-3">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="first_name">
                    Nombres {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="text"
                    className={`form-control ${errors.first_name ? 'is-invalid' : ''}`}
                    id="first_name"
                    placeholder="Ingrese nombres"
                    {...register('first_name', { required: !viewOnly ? 'Los nombres son requeridos' : false })}
                    readOnly={viewOnly}
                  />
                  {errors.first_name && <div className="invalid-feedback">{errors.first_name.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="last_name">
                    Apellidos {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="text"
                    className={`form-control ${errors.last_name ? 'is-invalid' : ''}`}
                    id="last_name"
                    placeholder="Ingrese apellidos"
                    {...register('last_name', { required: !viewOnly ? 'Los apellidos son requeridos' : false })}
                    readOnly={viewOnly}
                  />
                  {errors.last_name && <div className="invalid-feedback">{errors.last_name.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="birth_date">
                    Fecha de Nacimiento {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="date"
                    className={`form-control ${errors.birth_date ? 'is-invalid' : ''}`}
                    id="birth_date"
                    {...register('birth_date', { required: !viewOnly ? 'La fecha de nacimiento es requerida' : false })}
                    readOnly={viewOnly}
                  />
                  {errors.birth_date && <div className="invalid-feedback">{errors.birth_date.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="email">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                    id="email"
                    placeholder="Ingrese correo electrónico"
                    {...register('email', {
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Correo electrónico inválido"
                      }
                    })}
                    readOnly={viewOnly}
                  />
                  {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="document_type">
                    Tipo de Documento {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  {viewOnly ? (
                    <input
                      type="text"
                      className="form-control"
                      value={watch('document_type')}
                      readOnly
                    />
                  ) : (
                    <select
                      className={`form-select ${errors.document_type ? 'is-invalid' : ''}`}
                      id="document_type"
                      {...register('document_type', { required: !viewOnly ? 'El tipo de documento es requerido' : false })}
                    >
                      <option value="CC">Cédula de Ciudadanía</option>
                      <option value="CE">Cédula de Extranjería</option>
                      <option value="PP">Pasaporte</option>
                    </select>
                  )}
                  {errors.document_type && <div className="invalid-feedback">{errors.document_type.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="document_number">
                    Número de Documento {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="text"
                    className={`form-control ${errors.document_number ? 'is-invalid' : ''}`}
                    id="document_number"
                    placeholder="Ingrese número de documento"
                    {...register('document_number', { required: !viewOnly ? 'El número de documento es requerido' : false })}
                    readOnly={viewOnly}
                  />
                  {errors.document_number && <div className="invalid-feedback">{errors.document_number.message}</div>}
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="phone">
                    Teléfono {!viewOnly && <span className="text-danger">*</span>}
                  </label>
                  <input
                    type="tel"
                    className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                    id="phone"
                    placeholder="Ingrese teléfono"
                    {...register('phone', { required: !viewOnly ? 'El teléfono es requerido' : false })}
                    readOnly={viewOnly}
                  />
                  {errors.phone && <div className="invalid-feedback">{errors.phone.message}</div>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </DynamicModal>
  );
};

export default OwnerModal; 