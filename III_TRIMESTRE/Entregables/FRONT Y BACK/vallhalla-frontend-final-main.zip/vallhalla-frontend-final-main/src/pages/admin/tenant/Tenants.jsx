import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { ownersAPI } from '../../../services/apiService';
import toast from 'react-hot-toast';
import Swal from 'sweetalert2';
import TenantModal from './TenantModal';
import './Tenants.css';

const Tenants = () => {
  const [showModal, setShowModal] = useState(false);
  const [editingTenant, setEditingTenant] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  // Fetch owners data and filter for tenants
  const {
    data: ownersData,
    isLoading,
    error,
  } = useQuery('owners', ownersAPI.getDetails, {
    onSuccess: (data) => {
      console.log('Raw owners data:', data);
    },
    onError: (err) => {
      console.error('Error fetching tenants:', err);
      toast.error('Error al cargar los arrendatarios');
    },
  });

  const ownersRaw = ownersData?.owners || [];

  // Filter and map owners who are tenants
  const tenants = useMemo(() => {
    console.log('Processing owners:', ownersRaw);
    return ownersRaw
      .filter(owner => {
        console.log('Checking owner:', owner);
        return Boolean(owner.is_tenant);
      })
      .map((owner) => {
        console.log('Mapping tenant:', owner);
        return {
          id: owner.id,
          uniqueKey: `${owner.id}-${owner.user_id}-${owner.document_number || 'no-doc'}`,
          userId: owner.user_id,
          fullName: owner.full_name || owner.name || 'Sin nombre',
          email: owner.email || '',
          phone: owner.phone || '',
          documentType: owner.document_type || '',
          documentNumber: owner.document_number || '',
          birthDate: owner.birth_date,
          apartmentId: owner.apartment_id || 'No asignado',
          createdAt: owner.created_at,
          updatedAt: owner.updated_at,
          isTenant: Boolean(owner.is_tenant)
        };
      });
  }, [ownersRaw]);

  console.log('Processed tenants:', tenants);

  // Filter tenants based on search
  const filteredTenants = useMemo(() => {
    if (!searchTerm) return tenants;
    
    const filtered = tenants.filter((tenant) => {
      const fullName = (tenant.fullName || '').toLowerCase();
      const email = (tenant.email || '').toLowerCase();
      const documentNumber = tenant.documentNumber || '';
      const phone = tenant.phone || '';

      const term = searchTerm.toLowerCase();
      return (
        fullName.includes(term) ||
        email.includes(term) ||
        documentNumber.includes(term) ||
        phone.includes(term)
      );
    });

    return filtered;
  }, [tenants, searchTerm]);

  const handleCreate = () => {
    setEditingTenant(null);
    setShowModal(true);
  };

  const handleEdit = (tenant) => {
    setEditingTenant(tenant);
    setShowModal(true);
  };

  const handleDelete = (tenant) => {
    Swal.fire({
      title: '¿Está seguro?',
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then((result) => {
      if (result.isConfirmed) {
        deleteMutation.mutate(tenant.id);
      }
    });
  };

  const handleView = (tenant) => {
    Swal.fire({
      title: 'Detalles del Arrendatario',
      html: `
        <div class="text-start">
          <p><strong>Nombre completo:</strong> ${tenant.fullName}</p>
          <p><strong>Email:</strong> ${tenant.email}</p>
          <p><strong>Teléfono:</strong> ${tenant.phone}</p>
          <p><strong>Documento:</strong> ${tenant.documentType} ${tenant.documentNumber}</p>
          <p><strong>Fecha de Nacimiento:</strong> ${tenant.birthDate ? new Date(tenant.birthDate).toLocaleDateString() : ''}</p>
          <p><strong>ID Apartamento:</strong> ${tenant.apartmentId || 'No asignado'}</p>
        </div>
      `,
      confirmButtonText: 'Cerrar',
    });
  };

  // Mutations using ownersAPI but creating as tenants
  const createMutation = useMutation(
    (data) => ownersAPI.create({ ...data, is_tenant: true }), // Always create as tenant
    {
      onSuccess: () => {
        queryClient.invalidateQueries('owners');
        toast.success('Arrendatario creado exitosamente');
        setShowModal(false);
      },
      onError: (error) => {
        console.error('Create Tenant Error:', error);
        toast.error(error.response?.data?.message || 'Error al crear arrendatario');
      },
    }
  );

  const updateMutation = useMutation(
    ({ id, data }) => ownersAPI.update(id, { ...data, is_tenant: true }), // Ensure tenant status is maintained
    {
      onSuccess: () => {
        queryClient.invalidateQueries('owners');
        toast.success('Arrendatario actualizado exitosamente');
        setShowModal(false);
        setEditingTenant(null);
      },
      onError: (error) => {
        console.error('Update Tenant Error:', error);
        toast.error(error.response?.data?.message || 'Error al actualizar arrendatario');
      },
    }
  );

  const deleteMutation = useMutation(ownersAPI.delete, {
    onSuccess: () => {
      queryClient.invalidateQueries('owners');
      toast.success('Arrendatario eliminado exitosamente');
    },
    onError: (error) => {
      console.error('Delete Tenant Error:', error);
      toast.error(error.response?.data?.message || 'Error al eliminar arrendatario');
    },
  });

  const handleSubmit = (formData) => {
    if (editingTenant) {
      updateMutation.mutate({ 
        id: editingTenant.id, 
        data: { ...formData, is_tenant: true }
      });
    } else {
      createMutation.mutate({ ...formData, is_tenant: true });
    }
  };

  if (error) {
    return (
      <div className="alert alert-danger" role="alert">
        Error al cargar los arrendatarios: {error.message}
      </div>
    );
  }

  return (
    <div className="tenants-page">
      <div className="page-header">
        <div className="header-content">
          <h1>Gestión de Arrendatarios</h1>
          <p className="text-muted">
            Administre los arrendatarios del conjunto residencial
          </p>
        </div>
        <button
          className="btn btn-primary"
          onClick={handleCreate}
          disabled={isLoading}
        >
          <i className="bi bi-plus-lg"></i> Añadir Arrendatario
        </button>
      </div>

      {/* Search Section */}
      <div className="search-section">
        <div className="input-group">
          <span className="input-group-text">
            <i className="bi bi-search"></i>
          </span>
          <input
            type="text"
            className="form-control"
            placeholder="Buscar arrendatarios..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Tenants Table */}
      <div className="table-container">
        <div className="table-header">
          <h3>Lista de Arrendatarios</h3>
          <span className="badge bg-primary">
            {filteredTenants.length} arrendatarios
          </span>
        </div>

        {isLoading ? (
          <div className="loading-container">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Cargando...</span>
            </div>
            <p>Cargando arrendatarios...</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Nombre completo</th>
                  <th>Email</th>
                  <th>Documento</th>
                  <th>Teléfono</th>
                  <th>Apartamento</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredTenants.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center text-muted py-4">
                      {searchTerm
                        ? 'No se encontraron arrendatarios con ese criterio'
                        : 'No hay arrendatarios registrados'}
                    </td>
                  </tr>
                ) : (
                  filteredTenants.map((tenant) => (
                    <tr key={tenant.uniqueKey}>
                      <td>{tenant.fullName}</td>
                      <td>{tenant.email}</td>
                      <td>
                        {tenant.documentType} {tenant.documentNumber}
                      </td>
                      <td>{tenant.phone}</td>
                      <td>{tenant.apartmentId || 'No asignado'}</td>
                      <td>
                        <div className="btn-group" role="group">
                          <button
                            type="button"
                            className="btn btn-outline-primary btn-sm"
                            onClick={() => handleView(tenant)}
                            title="Ver detalles"
                          >
                            <i className="bi bi-eye"></i>
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                            onClick={() => handleEdit(tenant)}
                            title="Editar"
                          >
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-danger btn-sm"
                            onClick={() => handleDelete(tenant)}
                            title="Eliminar"
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Tenant Modal */}
      <TenantModal
        show={showModal}
        onHide={() => {
          setShowModal(false);
          setEditingTenant(null);
        }}
        onSubmit={handleSubmit}
        tenant={editingTenant}
        isLoading={createMutation.isLoading || updateMutation.isLoading}
      />
    </div>
  );
};

export default Tenants; 