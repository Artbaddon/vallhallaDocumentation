import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { visitorsAPI } from '../../../services/api';
import toast from 'react-hot-toast';
import Swal from 'sweetalert2';
import VisitorModal from './VisitorModal';
import './Visitors.css';

const Visitors = () => {
  const [showModal, setShowModal] = useState(false);
  const [editingVisitor, setEditingVisitor] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const queryClient = useQueryClient();

  // Fetch visitors data
  const { data: response, isLoading, error } = useQuery('visitors', visitorsAPI.getAll, {
    onSuccess: (response) => {
      console.log('Visitors data received:', response);
    },
    onError: (err) => {
      console.error('Error fetching visitors:', err);
    }
  });

  // Ensure visitors is always an array
  const visitors = Array.isArray(response) ? response : [];

  // Mutations
  const createMutation = useMutation(visitorsAPI.create, {
    onSuccess: () => {
      queryClient.invalidateQueries('visitors');
      toast.success('Visitante registrado exitosamente');
      setShowModal(false);
    },
    onError: (error) => {
      console.error('Create Visitor Error:', error);
      toast.error(error.response?.data?.message || 'Error al registrar visitante');
    }
  });

  const updateMutation = useMutation(
    ({ id, data }) => visitorsAPI.update(id, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('visitors');
        toast.success('Visitante actualizado exitosamente');
        setShowModal(false);
        setEditingVisitor(null);
      },
      onError: (error) => {
        console.error('Update Visitor Error:', error);
        toast.error(error.response?.data?.message || 'Error al actualizar visitante');
      }
    }
  );

  const deleteMutation = useMutation(visitorsAPI.delete, {
    onSuccess: () => {
      queryClient.invalidateQueries('visitors');
      toast.success('Visitante eliminado exitosamente');
    },
    onError: (error) => {
      console.error('Delete Visitor Error:', error);
      toast.error(error.response?.data?.message || 'Error al eliminar visitante');
    }
  });

  // Filter visitors based on search term and date
  const filteredVisitors = visitors.filter(visitor => {
    const visitorName = visitor.visitor_name || '';
    const visitorDocument = visitor.document_number || '';
    const enterDate = visitor.enter_date ? new Date(visitor.enter_date).toISOString().split('T')[0] : '';
    
    const matchesSearch = visitorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      visitorDocument.includes(searchTerm);
    
    const matchesDate = !dateFilter || enterDate === dateFilter;
    
    return matchesSearch && matchesDate;
  });

  const handleCreate = () => {
    setEditingVisitor(null);
    setShowModal(true);
  };

  const handleEdit = (visitor) => {
    setEditingVisitor({
      id: visitor.visitor_id,
      visitor_name: visitor.visitor_name,
      document_number: visitor.document_number,
      host_id: visitor.host_id
    });
    setShowModal(true);
  };

  const handleDelete = (visitor) => {
    Swal.fire({
      title: '¿Está seguro?',
      text: "Esta acción no se puede deshacer",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        deleteMutation.mutate(visitor.visitor_id);
      }
    });
  };

  const handleSubmit = (formData) => {
    console.log('Form data submitted:', formData);
    
    if (editingVisitor) {
      updateMutation.mutate({ id: editingVisitor.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  if (error) {
    return (
      <div className="alert alert-danger" role="alert">
        Error al cargar los visitantes: {error.message}
      </div>
    );
  }

  return (
    <div className="visitors-page">
      <div className="page-header">
        <div className="header-content">
          <h1>Gestión de Visitantes</h1>
          <p className="text-muted">Administre los visitantes del conjunto residencial</p>
        </div>
        <button 
          className="btn btn-primary" 
          onClick={handleCreate}
          disabled={isLoading}
        >
          <i className="bi bi-plus-lg"></i> Registrar Visitante
        </button>
      </div>

      {/* Search and Filters */}
      <div className="search-section">
        <div className="row">
          <div className="col-md-6">
            <div className="input-group">
              <span className="input-group-text">
                <i className="bi bi-search"></i>
              </span>
              <input
                type="text"
                className="form-control"
                placeholder="Buscar por nombre o documento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="input-group">
              <span className="input-group-text">
                <i className="bi bi-calendar"></i>
              </span>
              <input
                type="date"
                className="form-control"
                placeholder="Filtrar por fecha"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
              />
              {dateFilter && (
                <button 
                  className="btn btn-outline-secondary" 
                  type="button"
                  onClick={() => setDateFilter('')}
                >
                  <i className="bi bi-x"></i>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Visitors Table */}
      <div className="table-container">
        <div className="table-header">
          <h3>Lista de Visitantes</h3>
          <span className="badge bg-primary">{filteredVisitors.length} visitantes</span>
        </div>
        
        {isLoading ? (
          <div className="loading-container">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Cargando...</span>
            </div>
            <p>Cargando visitantes...</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Documento</th>
                  <th>Fecha de Entrada</th>
                  <th>Fecha de Salida</th>
                  <th>Anfitrión</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredVisitors.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center text-muted py-4">
                      {searchTerm || dateFilter ? 'No se encontraron visitantes con esos criterios' : 'No hay visitantes registrados'}
                    </td>
                  </tr>
                ) : (
                  filteredVisitors.map((visitor) => (
                    <tr key={visitor.visitor_id}>
                      <td>{visitor.visitor_name}</td>
                      <td>{visitor.document_number}</td>
                      <td>{formatDate(visitor.enter_date)}</td>
                      <td>{formatDate(visitor.exit_date) || 'Aún presente'}</td>
                      <td>{visitor.host_name || `ID: ${visitor.host_id}`}</td>
                      <td>
                        <div className="btn-group" role="group">
                          <button
                            type="button"
                            className="btn btn-outline-primary btn-sm"
                            onClick={() => handleEdit(visitor)}
                          >
                            <i className="bi bi-pencil"></i> Editar
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-danger btn-sm"
                            onClick={() => handleDelete(visitor)}
                          >
                            <i className="bi bi-trash"></i> Eliminar
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Visitor Modal */}
      {showModal && (
        <VisitorModal
          isOpen={showModal}
          onClose={() => {
            setShowModal(false);
            setEditingVisitor(null);
          }}
          onSubmit={handleSubmit}
          visitor={editingVisitor}
        />
      )}
    </div>
  );
};

export default Visitors; 