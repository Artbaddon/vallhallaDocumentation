import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { pqrsAPI, ownersAPI } from '../../../services/api';
import toast from 'react-hot-toast';

const PQRSModal = ({ show, handleClose, pqrs, categories }) => {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const queryClient = useQueryClient();
  const [isViewMode, setIsViewMode] = useState(false);

  // Fetch owners for dropdown
  const { data: ownersResponse = [] } = useQuery('owners', ownersAPI.getAll);
  
  // Extract owners data safely, handling different API response structures
  const extractOwners = () => {
    if (!ownersResponse) return [];
    
    // Handle different response structures
    if (Array.isArray(ownersResponse)) {
      return ownersResponse;
    }
    
    if (ownersResponse.data && Array.isArray(ownersResponse.data)) {
      return ownersResponse.data;
    }
    
    if (ownersResponse.data && ownersResponse.data.data && Array.isArray(ownersResponse.data.data)) {
      return ownersResponse.data.data;
    }
    
    return [];
  };
  
  const owners = extractOwners();

  // Mutations
  const createMutation = useMutation(pqrsAPI.create, {
    onSuccess: () => {
      queryClient.invalidateQueries('pqrs');
      toast.success('PQRS creado exitosamente');
      handleClose();
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || 'Error al crear PQRS');
    }
  });

  const updateMutation = useMutation(
    ({ id, data }) => pqrsAPI.update(id, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('pqrs');
        toast.success('PQRS actualizado exitosamente');
        handleClose();
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Error al actualizar PQRS');
      }
    }
  );

  // Reset form when modal opens/closes or pqrs changes
  useEffect(() => {
    if (show) {
      if (pqrs) {
        // If we have a PQRS, populate form with its data
        reset({
          subject: pqrs.subject || '',
          category_id: pqrs.category_id?.toString() || '',
          owner_id: pqrs.owner_id?.toString() || '',
          description: pqrs.description || '',
          priority: pqrs.priority || 'Medium'
        });
        // If we're viewing an existing PQRS, set view mode
        setIsViewMode(true);
      } else {
        // If creating new PQRS, reset form
        reset({
          subject: '',
          category_id: '',
          owner_id: '',
          description: '',
          priority: 'Medium'
        });
        setIsViewMode(false);
      }
    }
  }, [show, pqrs, reset]);

  const onSubmit = (data) => {
    // Convert string IDs to numbers
    const formattedData = {
      ...data,
      category_id: parseInt(data.category_id),
      owner_id: parseInt(data.owner_id)
    };

    if (pqrs) {
      updateMutation.mutate({ id: pqrs.id, data: formattedData });
    } else {
      createMutation.mutate(formattedData);
    }
  };

  const toggleEditMode = () => {
    setIsViewMode(!isViewMode);
  };

  // Get status name
  const getStatusName = (statusId) => {
    const statuses = {
      1: 'Pendiente',
      2: 'En proceso',
      3: 'Resuelto',
      4: 'Cerrado'
    };
    return statuses[statusId] || 'Desconocido';
  };

  // Helper function to find owner by ID
  const findOwnerById = (ownerId) => {
    const owner = owners.find(o => o.id === ownerId || o.Owner_id === ownerId);
    if (owner) {
      return owner.name || owner.first_name && owner.last_name ? 
        `${owner.first_name} ${owner.last_name}` : 
        `ID: ${ownerId}`;
    }
    return `ID: ${ownerId}`;
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          {pqrs ? (isViewMode ? 'Detalles de PQRS' : 'Editar PQRS') : 'Crear Nuevo PQRS'}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {pqrs && isViewMode ? (
          <div className="pqrs-details">
            <div className="row mb-3">
              <div className="col-md-6">
                <p><strong>Asunto:</strong> {pqrs.subject}</p>
                <p><strong>Categoría:</strong> {categories.find(c => c.id === pqrs.category_id)?.name || 'No especificada'}</p>
                <p><strong>Propietario:</strong> {findOwnerById(pqrs.owner_id)}</p>
                <p><strong>Prioridad:</strong> {pqrs.priority}</p>
              </div>
              <div className="col-md-6">
                <p><strong>Estado:</strong> {getStatusName(pqrs.status_id)}</p>
                <p><strong>Fecha de creación:</strong> {new Date(pqrs.created_at).toLocaleDateString()}</p>
                {pqrs.updated_at && (
                  <p><strong>Última actualización:</strong> {new Date(pqrs.updated_at).toLocaleDateString()}</p>
                )}
              </div>
            </div>
            <div className="mb-3">
              <h5>Descripción:</h5>
              <div className="p-3 bg-light rounded">
                {pqrs.description}
              </div>
            </div>
            {pqrs.admin_response && (
              <div className="mb-3">
                <h5>Respuesta del administrador:</h5>
                <div className="p-3 bg-light rounded">
                  {pqrs.admin_response}
                </div>
              </div>
            )}
          </div>
        ) : (
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mb-3">
              <Form.Label>Asunto</Form.Label>
              <Form.Control
                type="text"
                {...register('subject', { required: 'El asunto es requerido' })}
                isInvalid={!!errors.subject}
              />
              {errors.subject && (
                <Form.Control.Feedback type="invalid">
                  {errors.subject.message}
                </Form.Control.Feedback>
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Categoría</Form.Label>
              <Form.Select
                {...register('category_id', { required: 'La categoría es requerida' })}
                isInvalid={!!errors.category_id}
              >
                <option value="">Seleccione una categoría</option>
                {Array.isArray(categories) && categories.map(category => (
                  <option key={`category-${category.id || category.Category_id}`} value={(category.id || category.Category_id).toString()}>
                    {category.name || category.Category_name}
                  </option>
                ))}
              </Form.Select>
              {errors.category_id && (
                <Form.Control.Feedback type="invalid">
                  {errors.category_id.message}
                </Form.Control.Feedback>
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Propietario</Form.Label>
              <Form.Select
                {...register('owner_id', { required: 'El propietario es requerido' })}
                isInvalid={!!errors.owner_id}
              >
                <option value="">Seleccione un propietario</option>
                {Array.isArray(owners) && owners.map(owner => (
                  <option key={`owner-${owner.id || owner.Owner_id}`} value={(owner.id || owner.Owner_id).toString()}>
                    {owner.name || (owner.first_name && owner.last_name ? 
                      `${owner.first_name} ${owner.last_name}` : 
                      `ID: ${owner.id || owner.Owner_id}`)}
                  </option>
                ))}
              </Form.Select>
              {errors.owner_id && (
                <Form.Control.Feedback type="invalid">
                  {errors.owner_id.message}
                </Form.Control.Feedback>
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Prioridad</Form.Label>
              <Form.Select {...register('priority')}>
                <option value="Low">Baja</option>
                <option value="Medium">Media</option>
                <option value="High">Alta</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Descripción</Form.Label>
              <Form.Control
                as="textarea"
                rows={5}
                {...register('description', { required: 'La descripción es requerida' })}
                isInvalid={!!errors.description}
              />
              {errors.description && (
                <Form.Control.Feedback type="invalid">
                  {errors.description.message}
                </Form.Control.Feedback>
              )}
            </Form.Group>
          </Form>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Cerrar
        </Button>
        {pqrs ? (
          isViewMode ? (
            <Button variant="primary" onClick={toggleEditMode}>
              Editar
            </Button>
          ) : (
            <>
              <Button variant="secondary" onClick={toggleEditMode}>
                Cancelar Edición
              </Button>
              <Button 
                variant="primary" 
                onClick={handleSubmit(onSubmit)}
                disabled={updateMutation.isLoading}
              >
                {updateMutation.isLoading ? 'Guardando...' : 'Guardar Cambios'}
              </Button>
            </>
          )
        ) : (
          <Button 
            variant="primary" 
            onClick={handleSubmit(onSubmit)}
            disabled={createMutation.isLoading}
          >
            {createMutation.isLoading ? 'Creando...' : 'Crear PQRS'}
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  );
};

export default PQRSModal; 