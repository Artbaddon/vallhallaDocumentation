import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { petsAPI } from "../../../services/api";
import toast from "react-hot-toast";
import Swal from "sweetalert2";
import PetModal from "./PetModal";
import "./Pets.css";

const Pets = () => {
  const [showModal, setShowModal] = useState(false);
  const [editingPet, setEditingPet] = useState(null);
  const [viewingPet, setViewingPet] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const queryClient = useQueryClient();

  // Fetch pets data
  const { data: pets = [], isLoading, error, refetch } = useQuery({
    queryKey: ['pets'],
    queryFn: petsAPI.getAll,
    onError: (error) => {
      console.error('Error fetching pets:', error);
      toast.error("Error al cargar las mascotas");
    }
  });

  // Mapea el array crudo a un formato limpio y consistente para frontend
  const petsFormatted = useMemo(() => {
    if (!pets || !Array.isArray(pets)) return [];
    
    console.log("Processing pets data:", pets);
    return pets.map((pet) => {
      if (!pet) return null;
      console.log("Processing pet:", pet);
      return {
        id: pet.Pet_id || pet.id,
        name: pet.Pet_name || pet.name,
        species: pet.Pet_species || pet.species,
        breed: pet.Pet_breed || pet.breed,
        vaccinationCard: pet.Pet_vaccination_card || pet.vaccination_card,
        photo: pet.Pet_photo || pet.photo,
        ownerId: pet.Owner_FK_ID || pet.owner_id,
        ownerName: pet.Owner_name || pet.owner?.name || 'No Owner',
        createdAt: pet.created_at,
        updatedAt: pet.updated_at
      };
    }).filter(Boolean); // Remove any null entries
  }, [pets]);

  // Filtra sobre el array ya mapeado
  const filteredPets = useMemo(() => {
    if (!searchTerm) return petsFormatted;
    
    const filtered = petsFormatted.filter((pet) => {
      if (!pet) return false; // Skip invalid pets

      const name = (pet.name || '').toLowerCase();
      const species = (pet.species || '').toLowerCase();
      const breed = (pet.breed || '').toLowerCase();

      const term = searchTerm.toLowerCase();
      return (
        name.includes(term) ||
        species.includes(term) ||
        breed.includes(term)
      );
    });

    return filtered;
  }, [petsFormatted, searchTerm]);

  const handleCreate = () => {
    setEditingPet(null);
    setViewingPet(null);
    setShowModal(true);
  };

  const handleEdit = (pet) => {
    setEditingPet(pet);
    setViewingPet(null);
    setShowModal(true);
  };

  const handleView = (pet) => {
    setViewingPet(pet);
    setEditingPet(null);
    setShowModal(true);
  };

  const handleDelete = (pet) => {
    Swal.fire({
      title: "¿Está seguro?",
      text: `¿Desea eliminar a ${pet.name}?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc3545",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteMutation.mutate(pet.id);
      }
    });
  };

  // Mutations
  const createMutation = useMutation(petsAPI.create, {
    onSuccess: () => {
      queryClient.invalidateQueries("pets");
      toast.success("Mascota creada exitosamente");
      setShowModal(false);
    },
    onError: (error) => {
      console.error("Create Pet Error:", error);
      toast.error(
        error.response?.data?.message || "Error al crear mascota"
      );
    },
  });

  const updateMutation = useMutation(
    ({ id, data }) => petsAPI.update(id, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("pets");
        toast.success("Mascota actualizada exitosamente");
        setShowModal(false);
        setEditingPet(null);
      },
      onError: (error) => {
        console.error("Update Pet Error:", error);
        toast.error(
          error.response?.data?.message || "Error al actualizar mascota"
        );
      },
    }
  );

  const deleteMutation = useMutation(petsAPI.delete, {
    onSuccess: () => {
      queryClient.invalidateQueries("pets");
      toast.success("Mascota eliminada exitosamente");
    },
    onError: (error) => {
      console.error("Delete Pet Error:", error);
      toast.error(
        error.response?.data?.message || "Error al eliminar mascota"
      );
    },
  });

  const handleSubmit = async (formData) => {
    try {
      if (editingPet) {
        await updateMutation.mutateAsync({
          id: editingPet.id,
          ...formData
        });
        toast.success('Mascota actualizada exitosamente');
      } else {
        await createMutation.mutateAsync(formData);
        toast.success('Mascota creada exitosamente');
      }
      setShowModal(false);
      refetch(); // Refresh the pets list
    } catch (error) {
      console.error('Error:', error);
      toast.error(error.response?.data?.error || 'Error al procesar la mascota');
    }
  };

  if (error) {
    return (
      <div className="alert alert-danger" role="alert">
        Error al cargar las mascotas: {error.message}
      </div>
    );
  }

  return (
    <div className="pets-page">
      <div className="page-header">
        <div className="header-content">
          <h1>Gestión de Mascotas</h1>
          <p className="text-muted">
            Administre la información de las mascotas del conjunto
          </p>
        </div>
        <button
          className="btn btn-primary"
          onClick={handleCreate}
          disabled={isLoading}
        >
          <i className="bi bi-plus-lg"></i> Añadir Mascota
        </button>
      </div>

      {/* Search and Filters */}
      <div className="search-section">
        <div className="input-group">
          <span className="input-group-text">
            <i className="bi bi-search"></i>
          </span>
          <input
            type="text"
            className="form-control"
            placeholder="Buscar mascotas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Pets Table */}
      <div className="table-container">
        <div className="table-header">
          <h3>Lista de Mascotas</h3>
          <span className="badge bg-primary">
            {filteredPets.length} mascotas
          </span>
        </div>

        {isLoading ? (
          <div className="loading-container">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Cargando...</span>
            </div>
            <p>Cargando mascotas...</p>
          </div>
        ) : error ? (
          <div className="alert alert-danger">
            Error al cargar las mascotas. Por favor, intente de nuevo.
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Foto</th>
                  <th>Nombre</th>
                  <th>Especie</th>
                  <th>Raza</th>
                  <th>Carnet de Vacunas</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredPets.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center text-muted py-4">
                      {searchTerm
                        ? "No se encontraron mascotas con ese criterio"
                        : "No hay mascotas registradas"}
                    </td>
                  </tr>
                ) : (
                  filteredPets.map((pet) => (
                    <tr key={pet.id}>
                      <td>
                        <img 
                          src={pet.photo || '/default-pet.jpg'} 
                          alt={pet.name}
                          className="pet-thumbnail"
                          style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '50%' }}
                        />
                      </td>
                      <td>{pet.name}</td>
                      <td>{pet.species}</td>
                      <td>{pet.breed}</td>
                      <td>
                        {pet.vaccinationCard ? (
                          <a 
                            href={`/uploads/${pet.vaccinationCard}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="btn btn-sm btn-outline-primary"
                          >
                            <i className="bi bi-file-earmark-text me-1"></i>
                            Ver
                          </a>
                        ) : (
                          <span className="text-muted">No disponible</span>
                        )}
                      </td>
                      <td>
                        <div className="btn-group" role="group">
                          <button
                            type="button"
                            className="btn btn-outline-primary btn-sm"
                            onClick={() => handleView(pet)}
                            title="Ver detalles"
                          >
                            <i className="bi bi-eye"></i>
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                            onClick={() => handleEdit(pet)}
                            title="Editar"
                          >
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-danger btn-sm"
                            onClick={() => handleDelete(pet)}
                            title="Eliminar"
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pet Modal */}
      <PetModal
        show={showModal}
        onHide={() => {
          setShowModal(false);
          setEditingPet(null);
          setViewingPet(null);
        }}
        onSubmit={handleSubmit}
        pet={editingPet || viewingPet}
        isLoading={createMutation.isLoading || updateMutation.isLoading}
        viewOnly={Boolean(viewingPet)}
      />
    </div>
  );
};

export default Pets; 