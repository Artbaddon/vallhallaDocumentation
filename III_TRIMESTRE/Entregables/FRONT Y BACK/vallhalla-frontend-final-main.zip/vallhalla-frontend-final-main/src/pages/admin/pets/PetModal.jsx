import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { useQuery } from "react-query";
import { ownersAPI } from "../../../services/apiService";
import "./PetModal.css";

const PetModal = ({ show, onHide, onSubmit, initialData = null }) => {
  const [formData, setFormData] = useState({
    name: "",
    species: "",
    breed: "",
    owner_id: "",
    photo: null,
    vaccination_card: null
  });

  const [photoPreview, setPhotoPreview] = useState(null);
  const [validated, setValidated] = useState(false);

  // Fetch owners for dropdown
  const { data: owners = [] } = useQuery("owners", ownersAPI.getAll);

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || "",
        species: initialData.species || "",
        breed: initialData.breed || "",
        owner_id: initialData.ownerId || "",
        photo: null,
        vaccination_card: null
      });
      if (initialData.photo) {
        setPhotoPreview(initialData.photo);
      }
    }
  }, [initialData]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData(prev => ({
        ...prev,
        [name]: files[0]
      }));

      if (name === "photo") {
        const reader = new FileReader();
        reader.onloadend = () => {
          setPhotoPreview(reader.result);
        };
        reader.readAsDataURL(files[0]);
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    
    if (!form.checkValidity()) {
      e.stopPropagation();
      setValidated(true);
      return;
    }

    onSubmit(formData);
    onHide();
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>{initialData ? "Editar Mascota" : "Agregar Mascota"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Nombre</Form.Label>
            <Form.Control
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
            <Form.Control.Feedback type="invalid">
              Por favor ingrese el nombre de la mascota
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Especie</Form.Label>
            <Form.Control
              type="text"
              name="species"
              value={formData.species}
              onChange={handleInputChange}
              required
            />
            <Form.Control.Feedback type="invalid">
              Por favor ingrese la especie
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Raza</Form.Label>
            <Form.Control
              type="text"
              name="breed"
              value={formData.breed}
              onChange={handleInputChange}
              required
            />
            <Form.Control.Feedback type="invalid">
              Por favor ingrese la raza
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Propietario</Form.Label>
            <Form.Select
              name="owner_id"
              value={formData.owner_id}
              onChange={handleInputChange}
              required
            >
              <option value="">Seleccione un propietario</option>
              {owners.map(owner => (
                <option key={owner.Owner_id || owner.id} value={owner.Owner_id || owner.id}>
                  {owner.Owner_name || owner.name}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">
              Por favor seleccione un propietario
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Foto</Form.Label>
            <Form.Control
              type="file"
              name="photo"
              onChange={handleFileChange}
              accept="image/*"
              required={!initialData}
            />
            {photoPreview && (
              <img
                src={photoPreview}
                alt="Preview"
                className="mt-2"
                style={{ maxWidth: "200px", maxHeight: "200px" }}
              />
            )}
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Carnet de Vacunación</Form.Label>
            <Form.Control
              type="file"
              name="vaccination_card"
              onChange={handleFileChange}
              accept=".pdf,image/*"
              required={!initialData}
            />
          </Form.Group>

          <div className="d-flex justify-content-end gap-2">
            <Button variant="secondary" onClick={onHide}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary">
              {initialData ? "Actualizar" : "Crear"}
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default PetModal; 